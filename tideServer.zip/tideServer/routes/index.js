module.exports = {
    '/admin': 'admin/routehub'
};
